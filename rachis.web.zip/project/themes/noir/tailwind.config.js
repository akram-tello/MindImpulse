module.exports = {
  theme: {},
  variants: {},
  plugins: [],
}
