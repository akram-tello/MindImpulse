<a name="1.9.0"></a>
# [1.9.0](https://github.com/flextype-themes/noir) (2021-01-14)

### Features

* **core** update code base for new Flextype 0.9.16

<a name="1.8.1"></a>
# [1.8.1](https://github.com/flextype-themes/noir) (2021-01-07)

### Bug Fixes

* **core:** fix issue with content container.

<a name="1.8.0"></a>
# [1.8.0](https://github.com/flextype-themes/noir) (2021-01-07)

### Features

* **core** update code base for new Twig 2 plugin.

<a name="1.7.0"></a>
# [1.7.0](https://github.com/flextype-themes/noir) (2021-01-03)

### Features

* **core** update code base for new Flextype 0.9.15

<a name="1.6.0"></a>
# [1.6.0](https://github.com/flextype-themes/noir) (2020-12-30)

### Features

* **core** update code base for new Flextype 0.9.14
* **core** use new TWIG Plugin 1.7.0

<a name="1.5.0"></a>
# [1.5.0](https://github.com/flextype-themes/noir) (2020-12-20)

### Features

* **core** update code base for new Flextype 0.9.13

<a name="1.4.1"></a>
# [1.4.1](https://github.com/flextype-themes/noir) (2020-12-07)

### Bug fixes

* **core** fix navigation

<a name="1.4.0"></a>
# [1.4.0](https://github.com/flextype-themes/noir) (2020-12-07)

### Features

* **core** update code base for new Flextype 0.9.12

<a name="1.3.0"></a>
# [1.3.0](https://github.com/flextype-themes/noir) (2020-08-25)

### Features

* **core** update code base for new Flextype 0.9.11

<a name="1.2.0"></a>
# [1.2.0](https://github.com/flextype-themes/noir) (2020-08-19)

### Features

* **core** update code base for new Flextype 0.9.10

<a name="1.1.0"></a>
# [1.1.0](https://github.com/flextype-themes/noir) (2020-08-05)

### Features

* **core** update code base for new Flextype 0.9.9

<a name="1.0.1"></a>
# [1.0.1](https://github.com/flextype-themes/noir) (2020-05-09)

### Bug Fixes

* **core:** fix dependencies

<a name="1.0.0"></a>
# [1.0.0](https://github.com/flextype-themes/noir) (2020-05-09)
* Initial Release
