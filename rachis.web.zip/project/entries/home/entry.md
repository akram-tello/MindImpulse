---
title: Home
fieldset: page
template: default
menu_item_title: Home
menu_item_url: home
menu_item_target: _self
menu_item_order: '1'
created_by: 1d7d2731-c5cf-4ac3-9bb8-2bfd327cafc7
published_by: 1d7d2731-c5cf-4ac3-9bb8-2bfd327cafc7
published_at: '22-09-2021 11:34'
created_at: '22-09-2021 11:34'
description: ''
visibility: visible
routable: true
---
<h1 style="text-align: center; margin-top: 8rem" class="italic t1 my-32">Welcome to Mind Impulse Syestem website!<br> WE ARE BUILDING SOME AWESOME STAFF..</h1><p style="text-align: center;" class="lead">&nbsp; with <a href="./admin">Admin panel</a>.</p>
