---
subject: Welcome to {sitename}!
from: test@flextype.org
---
Welcome to {sitename}!<br><br>

Dear {user},<br><br>

Thanks for registering at {sitename}!<br> We are glad you have chosen to be a part of our community and we hope you enjoy your stay.<br><br>

All the best,<br>
{sitename}
