---
subject: Your new password for {sitename}!
---
Dear {user},<br><br>

As you requested, your password has now been reset.<br>
Your new details are as follows:<br><br>

Email: {email}<br>
Password: {password}<br><br>

To change your password, please visit this page: <a href="{url}/admin/accounts/edit?email={email}" style="color:#333; text-decoration:underline;">{url}/admin/accounts/edit?email={email}</a><br><br>

All the best,<br>
{sitename}
