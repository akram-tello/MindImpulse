<?php

declare(strict_types=1);

namespace Flextype;

include __DIR__ . '/bootstrap.php';
