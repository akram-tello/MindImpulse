$('.js-select-template').select2();
