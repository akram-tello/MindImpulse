<?php

declare(strict_types=1);

namespace Flextype\Plugin\ThemesAdmin;

include __DIR__ . '/bootstrap.php';
